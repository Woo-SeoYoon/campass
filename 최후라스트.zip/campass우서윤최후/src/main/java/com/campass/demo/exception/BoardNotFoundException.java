package com.campass.demo.exception;

public class BoardNotFoundException extends RuntimeException {
}
