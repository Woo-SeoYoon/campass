package com.campass.demo;

public enum OrderStatus {
	후기작성,구매완료
}
