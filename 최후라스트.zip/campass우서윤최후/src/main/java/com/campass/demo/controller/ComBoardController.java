package com.campass.demo.controller;


import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.campass.demo.dto.BoardDto;
import com.campass.demo.dto.ProductDto;
import com.campass.demo.dto.RestResponse;
import com.campass.demo.entity.Board;
import com.campass.demo.service.BoardService;

@RestController
public class ComBoardController {

	@Autowired
	private BoardService service;
	 
	String prin = "spring";
	//  글저장
	@PostMapping(value = "board/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> boardSave(BoardDto.boardSave dto, Principal principal){
		Board board = service.boardSave(dto, prin);
		return ResponseEntity.ok(new RestResponse("OK", board, "/board/read?bno=" + board.getBno()));
	}
	
	// 리스트 
	@GetMapping(value="/board/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> findAll(@RequestParam(defaultValue = "1") Integer pageno, String username) {
		return ResponseEntity.ok(new RestResponse("OK", service.findAll(pageno, username), null));
	}
	
	// 글읽기
	@GetMapping(value="/board/read/rest", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> read(@RequestParam Integer bno, Principal principal) {
		BoardDto.read dto = service.read(bno, prin);
		return ResponseEntity.ok(new RestResponse("OK", dto, null));
	}
}
