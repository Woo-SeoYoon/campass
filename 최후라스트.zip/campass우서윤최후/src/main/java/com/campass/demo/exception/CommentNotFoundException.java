package com.campass.demo.exception;

public class CommentNotFoundException extends RuntimeException {

}
